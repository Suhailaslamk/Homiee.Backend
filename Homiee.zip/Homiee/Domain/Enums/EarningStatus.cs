﻿namespace Homiee.Domain.Enums
{
   
     public enum EarningStatus
        {
            Pending,    
            Available,  
            Paid        
        }
    
}
