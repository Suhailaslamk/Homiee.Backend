﻿////using Homiee.Application.DTOs;
////using Homiee.Application.Interfaces.IRepository;
////using Homiee.Application.Interfaces.IServices;
////using Homiee.Common;
////using Homiee.Domain.Entities;
////using Homiee.Domain.Enums;
////using Microsoft.EntityFrameworkCore;
////using Homiee.Infrastructure.Data;


////namespace Homiee.Application.Services
////{

////    public class SellerOrderService : ISellerOrderService
////    {
////        private readonly IOrderRepository _orderRepo;
////        private readonly ISellersRepository _sellerRepo;
////        private readonly AppDbContext _dbContext;
////        private readonly INotificationService _notificationService;


////        public SellerOrderService(IOrderRepository orderRepo, ISellersRepository sellerRepo, AppDbContext dbContext, INotificationService notificationService)
////        {
////            _orderRepo = orderRepo;
////            _sellerRepo = sellerRepo;
////            _dbContext = dbContext;
////            _notificationService = notificationService;
////        }

////        public async Task<ApiResponse<PagedResult<SellerOrderDto>>> GetOrders(int userId, OrderQueryDto queryDto)
////        {
////            var seller = await _sellerRepo.GetByUserIdAsync(userId);

////            if (seller == null)
////                return new ApiResponse<PagedResult<SellerOrderDto>>(404, "Seller not found");

////            var query = _orderRepo.Query()
////                .Where(o => o.SellerId == seller.Id); // ✅ NOW VALID

////            if (!string.IsNullOrEmpty(queryDto.Status))
////            {
////                if (Enum.TryParse<OrderStatus>(queryDto.Status, true, out var status))
////                    query = query.Where(o => o.Status == status);
////            }

////            var total = await query.CountAsync();

////            var items = await query
////                .OrderByDescending(o => o.CreatedAt)
////                .Skip((queryDto.Page - 1) * queryDto.PageSize)
////                .Take(queryDto.PageSize)
////                .Select(o => new SellerOrderDto
////                {
////                    Id = o.Id,
////                    TotalAmount = o.TotalAmount,
////                    Status = o.Status.ToString(),
////                    CreatedAt = o.CreatedAt
////                })
////                .ToListAsync();

////            var result = new PagedResult<SellerOrderDto>(
////                200, "Success", items, total, queryDto.Page, queryDto.PageSize
////            );

////            return new ApiResponse<PagedResult<SellerOrderDto>>(200, "Orders fetched", result);
////        }

////        public async Task<ApiResponse<string>> UpdateStatus(int orderId, int userId, string status)
////        {
////            var seller = await _sellerRepo.GetByUserIdAsync(userId);
////            if (seller == null)
////                return new ApiResponse<string>(404, "Seller not found");

////            var order = await _orderRepo.GetByIdAsync(orderId);
////            if (order == null)
////                return new ApiResponse<string>(404, "Order not found");

////            if (order.SellerId != seller.Id)
////                return new ApiResponse<string>(403, "Unauthorized");

////            if (!Enum.TryParse<OrderStatus>(status, true, out var newStatus))
////                return new ApiResponse<string>(400, "Invalid status");

////            // Sellers can move: Placed → Processing → Shipped → Delivered
////            // Sellers CANNOT set Cancelled (only customer/admin can)
////            if (newStatus == OrderStatus.Cancelled)
////                return new ApiResponse<string>(403, "Sellers cannot cancel orders. Contact admin.");

////            order.UpdateStatus(newStatus);

////            _dbContext.Set<OrderStatusHistory>().Add(new OrderStatusHistory
////            {
////                OrderId = order.Id,
////                Status = newStatus.ToString(),
////                CreatedOn = DateTime.UtcNow
////            });

////            await _dbContext.SaveChangesAsync();

////            // Notify customer of status change
////            await _notificationService.SendAsync(
////                order.UserId,
////                "Order Update",
////                $"Your order #{order.Id} is now {newStatus}"
////            );

////            return new ApiResponse<string>(200, "Order status updated");
////        }
////        public async Task<ApiResponse<SellerOrderGetDetailsDto>> GetOrderById(int orderId, int userId)
////        {
////            var seller = await _sellerRepo.GetByUserIdAsync(userId);
////            if (seller == null)
////                return new ApiResponse<SellerOrderGetDetailsDto>(404, "Seller not found");

////            var order = await _orderRepo.Query()
////                .Include(o => o.Items)
////                    .ThenInclude(i => i.Product)
////                .Include(o => o.User)
////                .FirstOrDefaultAsync(o => o.Id == orderId);

////            if (order == null)
////                return new ApiResponse<SellerOrderGetDetailsDto>(404, "Order not found");

////            // 🔥 CRITICAL: seller can only see his items
////            var sellerItems = order.Items
////                .Where(i => i.SellerId == seller.Id)
////                .ToList();

////            if (!sellerItems.Any())
////                return new ApiResponse<SellerOrderGetDetailsDto>(403, "Unauthorized");

////            var dto = new SellerOrderGetDetailsDto
////            {
////                OrderId = order.Id,
////                Status = order.Status.ToString(),
////                TotalAmount = sellerItems.Sum(i => i.Price * i.Quantity),
////                CreatedAt = order.CreatedAt,

////                CustomerName = order.User.Name,
////                CustomerEmail = order.User.Email,

////                Items = sellerItems.Select(i => new SellerOrderItemsDto
////                {
////                    ProductId = i.ProductId,
////                    ProductName = i.Product.Name,
////                    Quantity = i.Quantity,
////                    Price = i.Price
////                }).ToList()
////            };

////            return new ApiResponse<SellerOrderGetDetailsDto>(200, "Success", dto);
////        }
////    }
////}



//using Homiee.Application.Interfaces.IRepository;
//using Homiee.Application.Interfaces.IServices;
//using Homiee.Common;
//using Homiee.Domain.Entities;
//using Homiee.Domain.Enums;
//using Homiee.Infrastructure.Data;
//using Microsoft.EntityFrameworkCore;
//using Homiee.Application.DTOs;

//namespace Homiee.Application.Services
//{
//    public class SellerOrderService : ISellerOrderService
//    {
//        private readonly IOrderRepository _orderRepo;
//        private readonly ISellersRepository _sellerRepo;
//        private readonly AppDbContext _dbContext;
//        private readonly INotificationService _notificationService;

//        public SellerOrderService(
//            IOrderRepository orderRepo,
//            ISellersRepository sellerRepo,
//            AppDbContext dbContext,
//            INotificationService notificationService)
//        {
//            _orderRepo = orderRepo;
//            _sellerRepo = sellerRepo;
//            _dbContext = dbContext;
//            _notificationService = notificationService;
//        }

//        public async Task<ApiResponse<PagedResult<SellerOrderDto>>> GetOrders(
//            int userId, OrderQueryDto queryDto)
//        {
//            var seller = await _sellerRepo.GetByUserIdAsync(userId);
//            if (seller == null)
//                return new ApiResponse<PagedResult<SellerOrderDto>>(404, "Seller not found");

//            var query = _orderRepo.Query()
//                .Where(o => o.SellerId == seller.Id);

//            if (!string.IsNullOrEmpty(queryDto.Status))
//            {
//                if (Enum.TryParse<OrderStatus>(queryDto.Status, true, out var status))
//                    query = query.Where(o => o.Status == status);
//            }

//            var total = await query.CountAsync();

//            var items = await query
//                .OrderByDescending(o => o.CreatedAt)
//                .Skip((queryDto.Page - 1) * queryDto.PageSize)
//                .Take(queryDto.PageSize)
//                .Select(o => new SellerOrderDto
//                {
//                    Id = o.Id,
//                    TotalAmount = o.TotalAmount,
//                    Status = o.Status.ToString(),
//                    CreatedAt = o.CreatedAt
//                })
//                .ToListAsync();

//            return new ApiResponse<PagedResult<SellerOrderDto>>(200, "Orders fetched",
//                new PagedResult<SellerOrderDto>(200, "Success", items, total,
//                    queryDto.Page, queryDto.PageSize));
//        }

//        public async Task<ApiResponse<string>> UpdateStatus(int orderId, int userId, string status)
//        {
//            var seller = await _sellerRepo.GetByUserIdAsync(userId);
//            if (seller == null)
//                return new ApiResponse<string>(404, "Seller not found");

//            var order = await _orderRepo.GetByIdAsync(orderId);
//            if (order == null)
//                return new ApiResponse<string>(404, "Order not found");

//            if (order.SellerId != seller.Id)
//                return new ApiResponse<string>(403, "Unauthorized");

//            if (!Enum.TryParse<OrderStatus>(status, true, out var newStatus))
//                return new ApiResponse<string>(400, "Invalid status value");

//            // Seller can move: Placed → Processing → Shipped → Delivered
//            // Seller CANNOT cancel (only customer or admin can)
//            if (newStatus == OrderStatus.Cancelled)
//                return new ApiResponse<string>(403, "Sellers cannot cancel orders");

//            order.UpdateStatus(newStatus);

//            _dbContext.Set<OrderStatusHistory>().Add(new OrderStatusHistory
//            {
//                OrderId = order.Id,
//                Status = newStatus.ToString(),
//                CreatedOn = DateTime.UtcNow
//            });

//            await _dbContext.SaveChangesAsync();

//            // Notify the customer
//            await _notificationService.SendAsync(
//                order.UserId,
//                "Order Update",
//                $"Your order #{order.Id} is now: {newStatus}");

//            return new ApiResponse<string>(200, "Order status updated");
//        }

//        public async Task<ApiResponse<SellerOrderGetDetailsDto>> GetOrderById(
//            int orderId, int userId)
//        {
//            var seller = await _sellerRepo.GetByUserIdAsync(userId);
//            if (seller == null)
//                return new ApiResponse<SellerOrderGetDetailsDto>(404, "Seller not found");

//            var order = await _orderRepo.Query()
//                .Include(o => o.Items).ThenInclude(i => i.Product)
//                .Include(o => o.User)
//                .FirstOrDefaultAsync(o => o.Id == orderId);

//            if (order == null)
//                return new ApiResponse<SellerOrderGetDetailsDto>(404, "Order not found");

//            // Seller can only see their own items
//            var sellerItems = order.Items.Where(i => i.SellerId == seller.Id).ToList();
//            if (!sellerItems.Any())
//                return new ApiResponse<SellerOrderGetDetailsDto>(403, "Unauthorized");

//            return new ApiResponse<SellerOrderGetDetailsDto>(200, "Success",
//                new SellerOrderGetDetailsDto
//                {
//                    OrderId = order.Id,
//                    Status = order.Status.ToString(),
//                    TotalAmount = sellerItems.Sum(i => i.Price * i.Quantity),
//                    CreatedAt = order.CreatedAt,
//                    CustomerName = order.User.Name,
//                    CustomerEmail = order.User.Email,
//                    Items = sellerItems.Select(i => new SellerOrderItemsDto
//                    {
//                        ProductId = i.ProductId,
//                        ProductName = i.Product?.Name ?? i.ProductName,
//                        Quantity = i.Quantity,
//                        Price = i.Price
//                    }).ToList()
//                });
//        }
//    }
//}














using Homiee.Application.DTOs;
using Homiee.Application.Interfaces.IRepository;
using Homiee.Application.Interfaces.IServices;
using Homiee.Common;
using Homiee.Domain.Entities;
using Homiee.Domain.Enums;
using Homiee.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Homiee.Application.Services
{
    public class SellerOrderService : ISellerOrderService
    {
        private readonly IOrderRepository _orderRepo;
        private readonly ISellersRepository _sellerRepo;
        private readonly AppDbContext _dbContext;
        private readonly INotificationService _notificationService;
        private readonly ISellerEarningService _earningService;

        public SellerOrderService(
            IOrderRepository orderRepo,
            ISellersRepository sellerRepo,
            AppDbContext dbContext,
            INotificationService notificationService,
            ISellerEarningService earningService)
        {
            _orderRepo = orderRepo;
            _sellerRepo = sellerRepo;
            _dbContext = dbContext;
            _notificationService = notificationService;
            _earningService = earningService;
        }

        public async Task<ApiResponse<PagedResult<SellerOrderDto>>> GetOrders(
            int userId, OrderQueryDto queryDto)
        {
            var seller = await _sellerRepo.GetByUserIdAsync(userId);
            if (seller == null)
                return new ApiResponse<PagedResult<SellerOrderDto>>(404, "Seller not found");

            var query = _orderRepo.Query()
                .Where(o => o.SellerId == seller.Id);

            if (!string.IsNullOrEmpty(queryDto.Status))
            {
                if (Enum.TryParse<OrderStatus>(queryDto.Status, true, out var status))
                    query = query.Where(o => o.Status == status);
            }

            var total = await query.CountAsync();

            var items = await query
                .OrderByDescending(o => o.CreatedAt)
                .Skip((queryDto.Page - 1) * queryDto.PageSize)
                .Take(queryDto.PageSize)
                .Select(o => new SellerOrderDto
                {
                    Id = o.Id,
                    TotalAmount = o.TotalAmount,
                    Status = o.Status.ToString(),
                    CreatedAt = o.CreatedAt
                })
                .ToListAsync();

            return new ApiResponse<PagedResult<SellerOrderDto>>(200, "Orders fetched",
                new PagedResult<SellerOrderDto>(200, "Success", items, total,
                    queryDto.Page, queryDto.PageSize));
        }

        public async Task<ApiResponse<string>> UpdateStatus(int orderId, int userId, string status)
        {
            var seller = await _sellerRepo.GetByUserIdAsync(userId);
            if (seller == null)
                return new ApiResponse<string>(404, "Seller not found");

            var order = await _orderRepo.GetByIdAsync(orderId);
            if (order == null)
                return new ApiResponse<string>(404, "Order not found");

            if (order.SellerId != seller.Id)
                return new ApiResponse<string>(403, "Unauthorized");

            if (!Enum.TryParse<OrderStatus>(status, true, out var newStatus))
                return new ApiResponse<string>(400, "Invalid status value");

            // Sellers can move: Placed → Processing → Shipped → Delivered
            // Sellers CANNOT cancel (only customer or admin can)
            if (newStatus == OrderStatus.Cancelled)
                return new ApiResponse<string>(403, "Sellers cannot cancel orders");

            order.UpdateStatus(newStatus);

            // Step 6: record status history entry with timestamp
            _dbContext.Set<OrderStatusHistory>().Add(new OrderStatusHistory
            {
                OrderId = order.Id,
                Status = newStatus,
                CreatedOn = DateTime.UtcNow
            });

            await _dbContext.SaveChangesAsync();

            // Notify the customer
            await _notificationService.SendAsync(
                order.UserId,
                "Order Update",
                $"Your order #{order.Id} is now: {newStatus}");

            // Step 5: trigger earning creation when order is delivered
            if (newStatus == OrderStatus.Delivered)
            {
                await _earningService.CreateEarningForOrder(
                    seller.Id, order.Id, order.TotalAmount);
            }
            

            return new ApiResponse<string>(200, "Order status updated");
        }

        public async Task<ApiResponse<SellerOrderGetDetailsDto>> GetOrderById(
            int orderId, int userId)
        {
            var seller = await _sellerRepo.GetByUserIdAsync(userId);
            if (seller == null)
                return new ApiResponse<SellerOrderGetDetailsDto>(404, "Seller not found");

            var order = await _orderRepo.Query()
                .Include(o => o.Items).ThenInclude(i => i.Product)
                .Include(o => o.User)
                .FirstOrDefaultAsync(o => o.Id == orderId);

            if (order == null)
                return new ApiResponse<SellerOrderGetDetailsDto>(404, "Order not found");

            var sellerItems = order.Items.Where(i => i.SellerId == seller.Id).ToList();
            if (!sellerItems.Any())
                return new ApiResponse<SellerOrderGetDetailsDto>(403, "Unauthorized");

            return new ApiResponse<SellerOrderGetDetailsDto>(200, "Success",
                new SellerOrderGetDetailsDto
                {
                    OrderId = order.Id,
                    Status = order.Status.ToString(),
                    TotalAmount = sellerItems.Sum(i => i.Price * i.Quantity),
                    CreatedAt = order.CreatedAt,
                    CustomerName = order.User.Name,
                    CustomerEmail = order.User.Email,
                    Items = sellerItems.Select(i => new SellerOrderItemsDto
                    {
                        ProductId = i.ProductId,
                        ProductName = i.Product?.Name ?? i.ProductName,
                        Quantity = i.Quantity,
                        Price = i.Price
                    }).ToList()
                });
        }

        // Step 6: full tracking history for an order (seller-owned only)
        public async Task<ApiResponse<List<OrderStatusHistoryDto>>> GetOrderTracking(
            int orderId, int userId)
        {
            var seller = await _sellerRepo.GetByUserIdAsync(userId);
            if (seller == null)
                return new ApiResponse<List<OrderStatusHistoryDto>>(404, "Seller not found");

            var order = await _orderRepo.GetByIdAsync(orderId);
            if (order == null)
                return new ApiResponse<List<OrderStatusHistoryDto>>(404, "Order not found");

            if (order.SellerId != seller.Id)
                return new ApiResponse<List<OrderStatusHistoryDto>>(403, "Unauthorized");

            var history = await _dbContext.Set<OrderStatusHistory>()
                .Where(h => h.OrderId == orderId)
                .OrderBy(h => h.CreatedOn)
                .Select(h => new OrderStatusHistoryDto
                {
                    Status = h.Status.ToString(),
                    CreatedAt = h.CreatedOn
                })
                .ToListAsync();

            return new ApiResponse<List<OrderStatusHistoryDto>>(200, "Success", history);
        }
    }
}