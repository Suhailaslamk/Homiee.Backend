﻿namespace Homiee.Application.DTOs
{
    public class UpdateCategoryDto
    {


        public string Name { get; set; }


    }
}

