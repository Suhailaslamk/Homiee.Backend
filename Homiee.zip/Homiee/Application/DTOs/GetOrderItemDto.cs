﻿namespace Homiee.Application.DTOs
{
    public class GetOrderItemDto
    {

        public int ProductId { get; set; } 
               public string ProductName { get; set; } 
                   public decimal Price { get; set; }  
                   public int Quantity { get; set; }
    }
}
