﻿using Homiee.Application.DTOs;
using Homiee.Application.Interfaces.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Homiee.Presentation.Controllers
{
    //[Authorize(Roles = "Customer")]
    [Authorize]
    [ApiController]
    [Route("api/address")]
    public class AddressController : ControllerBase
    {
        private readonly IAddressService _service;

        public AddressController(IAddressService service)
        {
            _service = service;
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst("userId")?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
                throw new UnauthorizedAccessException("Invalid or missing token");

            if (!int.TryParse(userIdClaim, out var userId))
                throw new UnauthorizedAccessException("Invalid userId claim");

            return userId;
        }


        [HttpGet]
        public async Task<IActionResult> Get()
            => Ok(await _service.GetAddresses(GetUserId()));

        [HttpPost]
        public async Task<IActionResult> Create(CreateAddressDto dto)
            => Ok(await _service.Create(GetUserId(), dto));

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, UpdateAddressDto dto)
            => Ok(await _service.Update(GetUserId(), id, dto));

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
            => Ok(await _service.Delete(GetUserId(), id));
    }
}
