﻿using Homiee.Application.DTOs;
using Homiee.Application.Interfaces.IServices;
using Homiee.Application.Services;
using Homiee.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Homiee.Presentation.Controllers
{
    [ApiController]
    [Route("api/profile")]
    public class ProfileController : ControllerBase
    {
        private readonly IProfileService _service;

        public ProfileController(IProfileService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var userIdClaim = User.FindFirst("userId");

            if (userIdClaim == null)
                return Unauthorized("UserId claim missing");

            var userId = int.Parse(userIdClaim.Value);
            return Ok(await _service.GetProfile(userId));
        }

        [Authorize]
        [HttpPut]
        public async Task<IActionResult> Update([FromForm] UpdateProfileDto dto)
        {
            var userIdClaim = User.FindFirst("userId")?.Value;

            if (!int.TryParse(userIdClaim, out var userId))
                return Unauthorized(new { message = "Invalid token" });

            var roleValue = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

            if (!Enum.TryParse<UserRole>(roleValue, out var role))
                return Unauthorized(new { message = "Invalid role" });

            var result = await _service.UpdateProfile(userId, roleValue, dto);

            return StatusCode(result.StatusCode, result);
        }

    }
}
