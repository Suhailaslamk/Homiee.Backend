﻿using Homiee.Application.Interfaces.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Homiee.Presentation.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/chat")]
    public class ChatController : ControllerBase
    {
        private readonly IChatService _chatService; 

        public ChatController(IChatService chatService)
        {
            _chatService = chatService;
        }

        private int GetUserId()
        {
            var claim = User.FindFirst("userId")?.Value;
            if (string.IsNullOrEmpty(claim) || !int.TryParse(claim, out var id))
                throw new UnauthorizedAccessException("Invalid token");
            return id;
        }

        // ❌ Was missing
        [HttpGet("inbox")]
        public async Task<IActionResult> GetInbox()
        {
            var data = await _chatService.GetInboxAsync(GetUserId());
            return Ok(data);
        }

        [HttpGet("{otherUserId:int}")]
        public async Task<IActionResult> GetConversation(int otherUserId)
        {
            var data = await _chatService.GetConversationAsync(GetUserId(), otherUserId);
            return Ok(data);
        }

        // ❌ Was missing
        [HttpPut("{senderId:int}/read")]
        public async Task<IActionResult> MarkAsRead(int senderId)
        {
            await _chatService.MarkAsReadAsync(senderId, GetUserId());
            return NoContent();
        }
    }
}